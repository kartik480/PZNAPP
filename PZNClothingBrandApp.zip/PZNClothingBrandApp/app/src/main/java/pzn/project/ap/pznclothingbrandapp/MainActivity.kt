package pzn.project.ap.pznclothingbrandapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.AbsoluteAlignment
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.accompanist.pager.ExperimentalPagerApi
import com.google.accompanist.pager.HorizontalPager
import com.google.accompanist.pager.HorizontalPagerIndicator
import com.google.accompanist.pager.rememberPagerState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.appcompat.app.AppCompatDelegate

import pzn.project.ap.pznclothingbrandapp.ui.theme.MyAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        enableEdgeToEdge()
        setContent {
            MyAppTheme(useDarkTheme = false) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color.White // <-- Force white background here
                ){
                    var showSplash by remember { mutableStateOf(true) }

                    LaunchedEffect(Unit) {
                        delay(3000)
                        showSplash = false
                    }

                    if (showSplash) {
                        SplashScreen(modifier = Modifier.fillMaxSize())
                    } else {
                        MainScreenWithBottomBar()
                    }
                }

            }
        }
    }
}

@Composable
fun SplashScreen(modifier: Modifier = Modifier) {
    Box(modifier = modifier) {
        RedBubbleBox(modifier = Modifier.padding(40.dp))
        RedBubbleBox(modifier = Modifier.align(Alignment.BottomEnd).padding(40.dp))
        Image(
            painter = painterResource(id = R.drawable.logo),
            contentDescription = "Logo",
            modifier = Modifier
                .align(Alignment.Center)
                .size(150.dp)
        )
    }
}

@Composable
fun RedBubbleBox(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(200.dp)
            .graphicsLayer(scaleX = 2.5f, scaleY = 2.1f)
            .clip(RoundedCornerShape(150.dp))
            .background(Color.Red)
    )
}

@Composable
fun MainScreenWithBottomBar() {
    var selectedTab by remember { mutableStateOf(0) }

    Scaffold(
        bottomBar = {
            BottomNavigationBar(selectedTab = selectedTab, onTabSelected = { selectedTab = it })
        },
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
        ) {
            when (selectedTab) {
                0 -> CategoryScreen()
                1 -> Text("Wishlist", modifier = Modifier.align(Alignment.Center))
                2 -> Text("Categories", modifier = Modifier.align(Alignment.Center))
                3 -> MyAccountScreen()
            }
        }
    }
}

@Composable
fun BottomNavigationBar(selectedTab: Int, onTabSelected: (Int) -> Unit) {
    NavigationBar(containerColor = Color.Red, tonalElevation = 4.dp) {
        BottomNavigationItem(Icons.Default.Home, "Home", selectedTab == 0) { onTabSelected(0) }
        BottomNavigationItem(Icons.Default.Favorite, "Wishlist", selectedTab == 1) { onTabSelected(1) }
        BottomNavigationItem(Icons.Default.List, "Category", selectedTab == 2) { onTabSelected(2) }
        BottomNavigationItem(Icons.Default.AccountCircle, "Account", selectedTab == 3) { onTabSelected(3) }
    }
}

@Composable
fun RowScope.BottomNavigationItem(icon: ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
    NavigationBarItem(
        selected = selected,
        onClick = onClick,
        icon = { Icon(imageVector = icon, contentDescription = label, tint = Color.White) },
        label = { Text(text = label, color = Color.White) },
        alwaysShowLabel = true
    )
}

@Composable
fun CategoryScreen() {
    val mainImages = listOf(R.drawable.image2, R.drawable.image4, R.drawable.image5)
    var currentIndex by remember { mutableStateOf(0) }
    var menuOpen by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(3000)
            currentIndex = (currentIndex + 1) % mainImages.size
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { menuOpen = !menuOpen }) {
                        Icon(Icons.Default.Menu, contentDescription = "Menu", tint = Color.Black, modifier = Modifier.size(24.dp))
                    }
                    Icon(Icons.Default.Search, contentDescription = "Search", tint = Color.Black, modifier = Modifier.size(24.dp))
                }
            }

            item {
                Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Image(painter = painterResource(id = R.drawable.logo), contentDescription = "Logo", modifier = Modifier.size(100.dp))
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 24.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        listOf("Men", "Women", "Kids").forEach { category ->
                            Text(text = category, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))
                Box(modifier = Modifier.fillMaxWidth().height(300.dp), contentAlignment = Alignment.Center) {
                    Image(
                        painter = painterResource(id = mainImages[currentIndex]),
                        contentDescription = "Main Carousel",
                        modifier = Modifier.fillMaxWidth(0.9f).clip(RoundedCornerShape(16.dp))
                    )
                }
            }

            item {
                MaterialCarousel()
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
                Text("Your Favourite Brands", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 16.dp))
            }

            item {
                FavouriteBrandCarousel()
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
                Text("PZN Brands", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 16.dp))
            }

            item {
                PznBrandsCarousel()
            }
        }

        if (menuOpen) {
            SideMenu(menuOpen = menuOpen, onCloseMenu = { menuOpen = false })
        }
    }
}

@Composable
fun SideMenu(menuOpen: Boolean, onCloseMenu: () -> Unit) {
    var accessoriesExpanded by remember { mutableStateOf(false) }
    var animeExpanded by remember { mutableStateOf(false) }
    var pznExpanded by remember { mutableStateOf(false) }
    var themesExpanded by remember { mutableStateOf(false) }

    if (menuOpen) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0x66000000))
                .clickable(onClick = onCloseMenu)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .width(250.dp)
                    .background(Color.White)
                    .padding(16.dp)
                    .align(Alignment.TopStart)
                    .clickable(enabled = false) {}
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Column {
                        Text(
                            "Accessories",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            modifier = Modifier.clickable {
                                accessoriesExpanded = !accessoriesExpanded
                            }
                        )
                        if (accessoriesExpanded) {
                            Column(modifier = Modifier.padding(start = 12.dp)) {
                                Text("Hats")
                                Text("Watches")
                                Text("Belts")
                            }
                        }
                    }

                    Column {
                        Text(
                            "Anime Brands",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            modifier = Modifier.clickable {
                                animeExpanded = !animeExpanded
                            }
                        )
                        if (animeExpanded) {
                            Column(modifier = Modifier.padding(start = 12.dp)) {
                                Text("Naruto")
                                Text("One Piece")
                                Text("Bleach")
                            }
                        }
                    }

                    Column {
                        Text(
                            "PznBrands",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            modifier = Modifier.clickable {
                                pznExpanded = !pznExpanded
                            }
                        )
                        if (pznExpanded) {
                            Column(modifier = Modifier.padding(start = 12.dp)) {
                                Text("Pzn X")
                                Text("Pzn Y")
                                Text("Pzn Z")
                            }
                        }
                    }

                    Column {
                        Text(
                            "Themes",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            modifier = Modifier.clickable {
                                themesExpanded = !themesExpanded
                            }
                        )
                        if (themesExpanded) {
                            Column(modifier = Modifier.padding(start = 12.dp)) {
                                Text("Dark")
                                Text("Light")
                                Text("Oceanic")
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalPagerApi::class)
@Composable
fun MaterialCarousel() {
    val images = listOf(R.drawable.image2, R.drawable.image4, R.drawable.image5)
    val pagerState = rememberPagerState()
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        while (true) {
            delay(3000)
            val nextPage = (pagerState.currentPage + 1) % images.size
            coroutineScope.launch {
                pagerState.animateScrollToPage(nextPage)
            }
        }
    }

    Column {
        Text(
            text = "Categories",
            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
            modifier = Modifier
                .padding(bottom = 8.dp)
                .align(AbsoluteAlignment.Left)
        )
        HorizontalPager(
            count = images.size,
            state = pagerState,
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
        ) { page ->
            Image(
                painter = painterResource(id = images[page]),
                contentDescription = "Material $page",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, Color.LightGray, RoundedCornerShape(16.dp))
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        HorizontalPagerIndicator(
            pagerState = pagerState,
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .padding(8.dp),
            activeColor = Color.Red
        )
    }
}

@Composable
fun FavouriteBrandCarousel() {
    LazyRow {
        items(5) {
            Box(
                modifier = Modifier
                    .padding(8.dp)
                    .size(120.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.LightGray),
                contentAlignment = Alignment.Center
            ) {
                Text("Brand ${it + 1}", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@OptIn(ExperimentalPagerApi::class)
@Composable
fun PznBrandsCarousel() {
    val images = listOf(
        R.drawable.image2,
        R.drawable.image5,
        R.drawable.image4,
    )

    val pagerState = rememberPagerState()
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        while (true) {
            delay(3000)
            val nextPage = (pagerState.currentPage + 1) % images.size
            coroutineScope.launch {
                pagerState.animateScrollToPage(nextPage)
            }
        }
    }

    Column {
        HorizontalPager(
            count = images.size,
            state = pagerState,
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
        ) { page ->
            Image(
                painter = painterResource(id = images[page]),
                contentDescription = "PZN Brand",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, Color.LightGray, RoundedCornerShape(16.dp))
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        HorizontalPagerIndicator(
            pagerState = pagerState,
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .padding(8.dp),
            activeColor = Color.Red
        )
    }
}

@Composable
fun MyAccountScreen() {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var paymentMethod by remember { mutableStateOf("") }
    var referralCode by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = Icons.Default.AccountCircle,
            contentDescription = "Profile Icon",
            modifier = Modifier
                .size(100.dp)
                .padding(16.dp),
            tint = Color.Gray
        )

        Spacer(modifier = Modifier.height(16.dp))

        AccountTextField("Name", name) { name = it }
        AccountTextField("Gmail", email) { email = it }
        AccountTextField("Phone Number", phone) { phone = it }
        AccountTextField("Payment Method", paymentMethod) { paymentMethod = it }
        AccountTextField("Referral Code", referralCode) { referralCode = it }

        Button(
            onClick = { /* Save action here */ },
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .fillMaxWidth()
        ) {
            Text("Save")
        }
    }
}

@Composable
fun AccountTextField(label: String, value: String, onValueChange: (String) -> Unit) {
    Text(
        text = label,
        fontWeight = FontWeight.Bold,
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 4.dp)
    )
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = Modifier.fillMaxWidth()
    )
    Spacer(modifier = Modifier.height(12.dp))
}